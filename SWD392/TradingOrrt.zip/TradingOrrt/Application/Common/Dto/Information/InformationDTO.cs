﻿namespace Application.Common.Dto.Information
{
    public class InformationDTO
    {
        public string Image {  get; set; }
    }
}
