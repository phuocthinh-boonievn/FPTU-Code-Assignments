﻿namespace Application.Common.Dto.Role
{
    public class RoleDTO
    {
        public string RoleName { get; set; } = string.Empty;
    }
}
