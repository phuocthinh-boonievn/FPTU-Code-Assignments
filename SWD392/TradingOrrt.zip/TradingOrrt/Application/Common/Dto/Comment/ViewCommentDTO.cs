﻿namespace Application.Common.Dto.Comment
{
    public class ViewCommentDTO
    {
        public string CommentMsg { get; set; }

        public string UserName { get; set; }
    }
}
