﻿using WPF_Repository;

namespace WPF_Service
{
    public class PCService : IPCService
    {

    }
}